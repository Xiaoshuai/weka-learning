package weka;

import weka.classifiers.CollectiveEvaluation;
import weka.classifiers.collective.functions.LLGC;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;



public class test {

  public static void main(String[] args) throws Exception {
    // load training data, set class
    
	    Instances train = DataSource.read("/home/fracpete/temp/data_subtraining.arff");
	    train.setClassIndex(train.numAttributes() - 1);

	    // load unlabeled data, set class
	    Instances unlabeled = DataSource.read("/home/fracpete/temp/data_subtest(unlabel).arff");
	    unlabeled.setClassIndex(unlabeled.numAttributes() - 1);
	    
	    // load test data, set class
	    Instances test = DataSource.read("/home/fracpete/temp/data_subtest(unlabel).arff");
	    test.setClassIndex(test.numAttributes() - 1);
	    
	    // configure classifier
	    LLGC llgc = new LLGC();
	    
	    // build classifier
	    llgc.buildClassifier(train, unlabeled);
	    
	    // evaluate classifier
	    CollectiveEvaluation eval = new CollectiveEvaluation(train);
	    eval.evaluateModel(llgc, test);
	    System.out.println(eval.toSummaryString());

  }
}






